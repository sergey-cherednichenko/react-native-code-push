package com.example;

import android.support.annotation.Nullable;

import com.facebook.react.ReactPackage;
import com.reactnativenavigation.NavigationApplication;
import com.microsoft.codepush.react.CodePush;

import java.util.List;
import java.util.Arrays;

public class MainApplication extends NavigationApplication {
    @Override
    public boolean isDebug() {
        return BuildConfig.DEBUG;
    }

    @Nullable
    @Override
    public String getJSBundleFile() {
      return CodePush.getJSBundleFile();
    }

    @Nullable
    @Override
    public List<ReactPackage> createAdditionalReactPackages() {
        return Arrays.<ReactPackage>asList(
          new CodePush("_1HGFG599-SpZiFhnJhO-FdIz8JO4JLhwe61m", MainApplication.this, BuildConfig.DEBUG)
      );
    }
}
