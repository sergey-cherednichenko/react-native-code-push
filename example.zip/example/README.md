# example

A simple usage example. If you're using redux, take a look at [example-redux](../example-redux).

## Installation - iOS

* In the `example/` folder, run `npm install`

> Make sure you're using npm ver 3. If you normally use npm ver 2 on your system and reluctant to upgrade, you can install [npm 3 alongside 2](https://www.npmjs.com/package/npm3). For more details see https://github.com/wix/react-native-navigation/issues/1

* Open `example/ios/example.xcodeproj` in Xcode and press the play button
