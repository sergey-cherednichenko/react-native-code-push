__STRESS_TEST__ = false;
import App from './src/app';
